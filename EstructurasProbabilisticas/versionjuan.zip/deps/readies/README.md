# Library cluster of common Redis Modules automation code

[bin](docs/bin.md): Utilities

[Cetara](cetara/README.md): C/C++ tools

[Paella](paella/README.md): Python automation library

[Shibumi](shibumi/README.md): Bash tools

[mk](mk/README.md): GNU Make-based build framework
