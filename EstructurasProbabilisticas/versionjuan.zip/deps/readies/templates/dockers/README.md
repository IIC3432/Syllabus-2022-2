### Using docker templates

Docker templates are written in the [jinja templating language](https://jinja.palletsprojects.com/) and stiched together via bin/dockerwrapper.py. Make runs these things - please see mk/docker.rules.
