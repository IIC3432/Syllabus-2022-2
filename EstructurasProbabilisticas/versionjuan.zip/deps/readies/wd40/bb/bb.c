
#include "cetara/diag/gdb.h"

void _BB() {
    BB;
}
