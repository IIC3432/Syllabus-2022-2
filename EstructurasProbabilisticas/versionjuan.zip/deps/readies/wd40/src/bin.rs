
extern crate readies_wd40;
use crate::readies_wd40::{BB};

fn main() {
    BB!();
    println!("Moving, doing it, you know.");
}
